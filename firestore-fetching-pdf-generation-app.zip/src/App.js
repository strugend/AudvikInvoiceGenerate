import React from 'react';
import DataFetching from './DataFetching';

const App = () => {
  return (
    <div>
      <h1>Data Fetching from Firestore</h1>
      <DataFetching />
    </div>
  );
};

export default App;
