import React, { useEffect, useState } from "react";
import { firestore } from "./firebaseConfig";
import {
  Document,
  Page,
  Text,
  View,
  StyleSheet,
  PDFDownloadLink,
  PDFViewer
} from "@react-pdf/renderer";

const styles = StyleSheet.create({
    page: {
      fontFamily: 'Montserrat',
      fontSize: 12,
      padding: 40,
      backgroundColor: '#f2f2f2',
    },
    section: {
      marginBottom: 30,
      backgroundColor: '#ffffff',
      padding: 20,
      borderRadius: 10,
      boxShadow: '0 2px 6px rgba(0, 0, 0, 0.1)',
    },
    title: {
      fontSize: 32,
      marginBottom: 40,
      color: '#333333',
      fontWeight: 'bold',
      textAlign: 'center',
      textTransform: 'uppercase',
    },
    subtitle: {
      fontSize: 20,
      marginBottom: 20,
      color: '#ff5a5f',
      fontWeight: 'bold',
      textTransform: 'uppercase',
    },
    text: {
      marginBottom: 10,
      color: '#333333',
    },
    price: {
      fontSize: 24,
      fontWeight: 'bold',
      color: '#333333',
    },
  });
  

function convertTimestampToDateTime(timestamp) {
  return new Date(
    timestamp.seconds.toString() * 1000 +
      timestamp.nanoseconds.toString() / 1000000
  ).toLocaleString();
}

const DataFetching = () => {
  const [data, setData] = useState(null);
  const orderData = {
    Completed: data[0].Completed ? "true" : "false",
    Cooked: data[0].Cooked ? "true" : "false",
    Date: convertTimestampToDateTime(data[0].DateTime),
    Delivered: data[0].Delivered ? "true" : "false",
    OrderPrice: data[0].OrderPrice,
    StoreFoodDetails: data[0].StoreFoodDetails.toString(),
    offer: data[0].offer,
    personAddress: data[0].personAddress,
    personName: data[0].personName,
    personPaymentType: data[0].personPaymentType,
    personPhone: data[0].personPhone,
    tableNumber: data[0].tableNumber,
    timeline: data[0].timeline,
    uid: data[0].uid,
  };
  const {
    Completed,
    Cooked,
    Date,
    Delivered,
    OrderPrice,
    StoreFoodDetails,
    offer,
    personAddress,
    personName,
    personPaymentType,
    personPhone,
    tableNumber,
    timeline,
    uid,
  } = orderData;
  const MyDocument = () => (
    <Document>
      <Page size="A4" style={styles.page}>
        <View style={styles.section}>
          <Text style={styles.title}>Invoice</Text>
          <Text style={styles.subtitle}>Order Details</Text>
          <Text style={styles.text}>Order ID: {uid}</Text>
          <Text style={styles.text}>Order Date: {Date}</Text>
          <Text style={styles.text}>Table Number: {tableNumber}</Text>
          <Text style={styles.text}>Timeline: {timeline}</Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.subtitle}>Customer Details</Text>
          <Text style={styles.text}>Name: {personName}</Text>
          <Text style={styles.text}>Address: {personAddress}</Text>
          <Text style={styles.text}>Phone: {personPhone}</Text>
          <Text style={styles.text}>Payment Type: {personPaymentType}</Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.subtitle}>Order Summary</Text>
          <Text style={styles.text}>Total Price: ${OrderPrice}</Text>
          <Text style={styles.text}>Offer: {offer}</Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.subtitle}>Food Details</Text>
          <Text style={styles.text}>{StoreFoodDetails}</Text>
        </View>
      </Page>
    </Document>
  );

  useEffect(() => {
    const fetchData = async () => {
      try {
        const collectionRef = firestore.collection("order");
        const snapshot = await collectionRef.get();
        const fetchedData = snapshot.docs.map((doc) => doc.data());
        setData(fetchedData);
        console.log(fetchedData);
      } catch (error) {
        console.error("Error fetching data: ", error);
      }
    };

    fetchData();
  }, []);

  return (
    <>
      <div>
        {data ? (
          // <ul>
          //   {data.map((item) => (
          //     <li key={item.uid}>{item.personName}</li>
          //   ))}
          // </ul>
          <div>
            <p>Completed: {data[0].Completed ? "true" : "false"}</p>
            <p>Cooked: {data[0].Cooked ? "true" : "false"}</p>
            <p>Date: {convertTimestampToDateTime(data[0].DateTime)}</p>
            <p>Delivered: {data[0].Delivered ? "true" : "false"}</p>
            <p>OrderPrice: {data[0].OrderPrice}</p>
            <p>StoreFoodDetails: {data[0].StoreFoodDetails.toString()}</p>
            <p>offer: {data[0].offer}</p>
            <p>personAddress: {data[0].personAddress}</p>
            <p>personName: {data[0].personName}</p>
            <p>personPaymentType: {data[0].personPaymentType}</p>
            <p>personPhone: {data[0].personPhone}</p>
            <p>tableNumber: {data[0].tableNumber}</p>
            <p>timeline: {data[0].timeline}</p>
            <p>uid: {data[0].uid}</p>
          </div>
        ) : (
          <p>Loading data...</p>
        )}
      </div>

      <div>
        <PDFDownloadLink document={<MyDocument />} fileName="document.pdf">
          {({ blob, url, loading, error }) =>
            loading ? "Loading document..." : "Download as PDF"
          }
        </PDFDownloadLink>
      </div>
    </>
  );
};

export default DataFetching;
